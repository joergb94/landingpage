
<header id="header" class="">
        <div  class="container-head-dp" >
                       
                        <div class="centered-head-dp">
                            <div class="col-sm-10 text-left">
                                    <h1 id="head-i-y" class="text-head title-head-dp">STAFFING 24/7<br/>TO MEET YOUR NEEDS</h1>
                            </div>
                            <br>
                        </div>
                    </div> 
</header>
<?php /**PATH C:\Users\PC\Documents\GitHub\landingpage\resources\views/website/items/header.blade.php ENDPATH**/ ?>