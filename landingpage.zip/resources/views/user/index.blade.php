@extends('layouts.app')
@section('content')   
    <user-component></user-component>    
@endsection
