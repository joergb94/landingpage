<html lang="es">

<head>
  <meta charset="UTF-8">
  <title>Dedicated People -Mexico</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="max-image-preview:large">
  <title>Dedicated People -Mexico</title>
  <link href="{{ asset('css/LineIcons.css')}}" rel="stylesheet">
  <link href="https://cdn.lineicons.com/2.0/LineIcons.css" rel="stylesheet">
  <script type="text/javascript" id="www-widgetapi-script" src="{{ asset('css/www-widgetapi.js')}}" async=""></script>
  <script src="{{ asset('css/iframe_api.js')}}"></script>
  <script>
  window._wpemojiSettings = {
    "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/",
    "ext": ".png",
    "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/",
    "svgExt": ".svg",
    "source": {
      "concatemoji": "http:\/\/elmercadomorado.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.9.3"
    }
  };
  /*! This file is auto-generated */
  ! function(e, a, t) {
    var n, r, o, i = a.createElement("canvas"),
      p = i.getContext && i.getContext("2d");

    function s(e, t) {
      var a = String.fromCharCode;
      p.clearRect(0, 0, i.width, i.height), p.fillText(a.apply(this, e), 0, 0);
      e = i.toDataURL();
      return p.clearRect(0, 0, i.width, i.height), p.fillText(a.apply(this, t), 0, 0), e === i.toDataURL()
    }

    function c(e) {
      var t = a.createElement("script");
      t.src = e, t.defer = t.type = "text/javascript", a.getElementsByTagName("head")[0].appendChild(t)
    }
    for (o = Array("flag", "emoji"), t.supports = {
        everything: !0,
        everythingExceptFlag: !0
      }, r = 0; r < o.length; r++) t.supports[o[r]] = function(e) {
      if (!p || !p.fillText) return !1;
      switch (p.textBaseline = "top", p.font = "600 32px Arial", e) {
        case "flag":
          return s([127987, 65039, 8205, 9895, 65039], [127987, 65039, 8203, 9895, 65039]) ? !1 : !s([55356, 56826,
            55356, 56819
          ], [55356, 56826, 8203, 55356, 56819]) && !s([55356, 57332, 56128, 56423, 56128, 56418, 56128, 56421,
            56128, 56430, 56128, 56423, 56128, 56447
          ], [55356, 57332, 8203, 56128, 56423, 8203, 56128, 56418, 8203, 56128, 56421, 8203, 56128, 56430, 8203,
            56128, 56423, 8203, 56128, 56447
          ]);
        case "emoji":
          return !s([10084, 65039, 8205, 55357, 56613], [10084, 65039, 8203, 55357, 56613])
      }
      return !1
    }(o[r]), t.supports.everything = t.supports.everything && t.supports[o[r]], "flag" !== o[r] && (t.supports
      .everythingExceptFlag = t.supports.everythingExceptFlag && t.supports[o[r]]);
    t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && !t.supports.flag, t.DOMReady = !1, t
      .readyCallback = function() {
        t.DOMReady = !0
      }, t.supports.everything || (n = function() {
        t.readyCallback()
      }, a.addEventListener ? (a.addEventListener("DOMContentLoaded", n, !1), e.addEventListener("load", n, !1)) : (e
        .attachEvent("onload", n), a.attachEvent("onreadystatechange", function() {
          "complete" === a.readyState && t.readyCallback()
        })), (n = t.source || {}).concatemoji ? c(n.concatemoji) : n.wpemoji && n.twemoji && (c(n.twemoji), c(n
        .wpemoji)))
  }(window, document, window._wpemojiSettings);
  </script>
  <script src="{{ asset('css/wp-emoji-release.min.js')}}" type="text/javascript" defer=""></script>
  <script src="{{ asset('css/lottie-player.js')}}"></script>
  <style>
  img.wp-smiley,
  img.emoji {
    display: inline !important;
    border: none !important;
    box-shadow: none !important;
    height: 1em !important;
    width: 1em !important;
    margin: 0 0.07em !important;
    vertical-align: -0.1em !important;
    background: none !important;
    padding: 0 !important;
  }
  </style>
  <style id="wp-block-library-inline-css">
  :root {
    --wp-admin-theme-color: #007cba;
    --wp-admin-theme-color--rgb: 0, 124, 186;
    --wp-admin-theme-color-darker-10: #006ba1;
    --wp-admin-theme-color-darker-10--rgb: 0, 107, 161;
    --wp-admin-theme-color-darker-20: #005a87;
    --wp-admin-theme-color-darker-20--rgb: 0, 90, 135;
    --wp-admin-border-width-focus: 2px
  }

  @media (-webkit-min-device-pixel-ratio:2),
  (min-resolution:192dpi) {
    :root {
      --wp-admin-border-width-focus: 1.5px
    }
  }

  :root {
    --wp--preset--font-size--normal: 16px;
    --wp--preset--font-size--huge: 42px
  }

  :root .has-very-light-gray-background-color {
    background-color: #eee
  }

  :root .has-very-dark-gray-background-color {
    background-color: #313131
  }

  :root .has-very-light-gray-color {
    color: #eee
  }

  :root .has-very-dark-gray-color {
    color: #313131
  }

  :root .has-vivid-green-cyan-to-vivid-cyan-blue-gradient-background {
    background: linear-gradient(135deg, #00d084, #0693e3)
  }

  :root .has-purple-crush-gradient-background {
    background: linear-gradient(135deg, #34e2e4, #4721fb 50%, #ab1dfe)
  }

  :root .has-hazy-dawn-gradient-background {
    background: linear-gradient(135deg, #faaca8, #dad0ec)
  }

  :root .has-subdued-olive-gradient-background {
    background: linear-gradient(135deg, #fafae1, #67a671)
  }

  :root .has-atomic-cream-gradient-background {
    background: linear-gradient(135deg, #fdd79a, #004a59)
  }

  :root .has-nightshade-gradient-background {
    background: linear-gradient(135deg, #330968, #31cdcf)
  }

  :root .has-midnight-gradient-background {
    background: linear-gradient(135deg, #020381, #2874fc)
  }

  .has-regular-font-size {
    font-size: 1em
  }

  .has-larger-font-size {
    font-size: 2.625em
  }

  .has-normal-font-size {
    font-size: var(--wp--preset--font-size--normal)
  }

  .has-huge-font-size {
    font-size: var(--wp--preset--font-size--huge)
  }

  .has-text-align-center {
    text-align: center
  }

  .has-text-align-left {
    text-align: left
  }

  .has-text-align-right {
    text-align: right
  }

  #end-resizable-editor-section {
    display: none
  }

  .aligncenter {
    clear: both
  }

  .items-justified-left {
    justify-content: flex-start
  }

  .items-justified-center {
    justify-content: center
  }

  .items-justified-right {
    justify-content: flex-end
  }

  .items-justified-space-between {
    justify-content: space-between
  }

  .screen-reader-text {
    border: 0;
    clip: rect(1px, 1px, 1px, 1px);
    -webkit-clip-path: inset(50%);
    clip-path: inset(50%);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
    word-wrap: normal !important
  }

  .screen-reader-text:focus {
    background-color: #ddd;
    clip: auto !important;
    -webkit-clip-path: none;
    clip-path: none;
    color: #444;
    display: block;
    font-size: 1em;
    height: auto;
    left: 5px;
    line-height: normal;
    padding: 15px 23px 14px;
    text-decoration: none;
    top: 5px;
    width: auto;
    z-index: 100000
  }

  html :where(img[class*=wp-image-]) {
    height: auto;
    max-width: 100%
  }
  </style>
  <style id="global-styles-inline-css">
  body {
    --wp--preset--color--black: #000000;
    --wp--preset--color--cyan-bluish-gray: #abb8c3;
    --wp--preset--color--white: #ffffff;
    --wp--preset--color--pale-pink: #f78da7;
    --wp--preset--color--vivid-red: #cf2e2e;
    --wp--preset--color--luminous-vivid-orange: #ff6900;
    --wp--preset--color--luminous-vivid-amber: #fcb900;
    --wp--preset--color--light-green-cyan: #7bdcb5;
    --wp--preset--color--vivid-green-cyan: #00d084;
    --wp--preset--color--pale-cyan-blue: #8ed1fc;
    --wp--preset--color--vivid-cyan-blue: #0693e3;
    --wp--preset--color--vivid-purple: #9b51e0;
    --wp--preset--color--foreground: #000000;
    --wp--preset--color--background: #ffffff;
    --wp--preset--color--primary: #1a4548;
    --wp--preset--color--secondary: #ffe2c7;
    --wp--preset--color--tertiary: #F6F6F6;
    --wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg, rgba(6, 147, 227, 1) 0%, rgb(155, 81, 224) 100%);
    --wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg, rgb(122, 220, 180) 0%, rgb(0, 208, 130) 100%);
    --wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg, rgba(252, 185, 0, 1) 0%, rgba(255, 105, 0, 1) 100%);
    --wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg, rgba(255, 105, 0, 1) 0%, rgb(207, 46, 46) 100%);
    --wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg, rgb(238, 238, 238) 0%, rgb(169, 184, 195) 100%);
    --wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg, rgb(74, 234, 220) 0%, rgb(151, 120, 209) 20%, rgb(207, 42, 186) 40%, rgb(238, 44, 130) 60%, rgb(251, 105, 98) 80%, rgb(254, 248, 76) 100%);
    --wp--preset--gradient--blush-light-purple: linear-gradient(135deg, rgb(255, 206, 236) 0%, rgb(152, 150, 240) 100%);
    --wp--preset--gradient--blush-bordeaux: linear-gradient(135deg, rgb(254, 205, 165) 0%, rgb(254, 45, 45) 50%, rgb(107, 0, 62) 100%);
    --wp--preset--gradient--luminous-dusk: linear-gradient(135deg, rgb(255, 203, 112) 0%, rgb(199, 81, 192) 50%, rgb(65, 88, 208) 100%);
    --wp--preset--gradient--pale-ocean: linear-gradient(135deg, rgb(255, 245, 203) 0%, rgb(182, 227, 212) 50%, rgb(51, 167, 181) 100%);
    --wp--preset--gradient--electric-grass: linear-gradient(135deg, rgb(202, 248, 128) 0%, rgb(113, 206, 126) 100%);
    --wp--preset--gradient--midnight: linear-gradient(135deg, rgb(2, 3, 129) 0%, rgb(40, 116, 252) 100%);
    --wp--preset--gradient--vertical-secondary-to-tertiary: linear-gradient(to bottom, var(--wp--preset--color--secondary) 0%, var(--wp--preset--color--tertiary) 100%);
    --wp--preset--gradient--vertical-secondary-to-background: linear-gradient(to bottom, var(--wp--preset--color--secondary) 0%, var(--wp--preset--color--background) 100%);
    --wp--preset--gradient--vertical-tertiary-to-background: linear-gradient(to bottom, var(--wp--preset--color--tertiary) 0%, var(--wp--preset--color--background) 100%);
    --wp--preset--gradient--diagonal-primary-to-foreground: linear-gradient(to bottom right, var(--wp--preset--color--primary) 0%, var(--wp--preset--color--foreground) 100%);
    --wp--preset--gradient--diagonal-secondary-to-background: linear-gradient(to bottom right, var(--wp--preset--color--secondary) 50%, var(--wp--preset--color--background) 50%);
    --wp--preset--gradient--diagonal-background-to-secondary: linear-gradient(to bottom right, var(--wp--preset--color--background) 50%, var(--wp--preset--color--secondary) 50%);
    --wp--preset--gradient--diagonal-tertiary-to-background: linear-gradient(to bottom right, var(--wp--preset--color--tertiary) 50%, var(--wp--preset--color--background) 50%);
    --wp--preset--gradient--diagonal-background-to-tertiary: linear-gradient(to bottom right, var(--wp--preset--color--background) 50%, var(--wp--preset--color--tertiary) 50%);
    --wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');
    --wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');
    --wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');
    --wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');
    --wp--preset--duotone--midnight: url('#wp-duotone-midnight');
    --wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');
    --wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');
    --wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');
    --wp--preset--duotone--foreground-and-background: url('#wp-duotone-foreground-and-background');
    --wp--preset--duotone--foreground-and-secondary: url('#wp-duotone-foreground-and-secondary');
    --wp--preset--duotone--foreground-and-tertiary: url('#wp-duotone-foreground-and-tertiary');
    --wp--preset--duotone--primary-and-background: url('#wp-duotone-primary-and-background');
    --wp--preset--duotone--primary-and-secondary: url('#wp-duotone-primary-and-secondary');
    --wp--preset--duotone--primary-and-tertiary: url('#wp-duotone-primary-and-tertiary');
    --wp--preset--font-size--small: 1rem;
    --wp--preset--font-size--medium: 1.125rem;
    --wp--preset--font-size--large: 1.75rem;
    --wp--preset--font-size--x-large: clamp(1.75rem, 3vw, 2.25rem);
    --wp--preset--font-family--system-font: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    --wp--preset--font-family--source-serif-pro: "Source Serif Pro", serif;
    --wp--custom--spacing--small: max(1.25rem, 5vw);
    --wp--custom--spacing--medium: clamp(2rem, 8vw, calc(4 * var(--wp--style--block-gap)));
    --wp--custom--spacing--large: clamp(4rem, 10vw, 8rem);
    --wp--custom--spacing--outer: var(--wp--custom--spacing--small, 1.25rem);
    --wp--custom--typography--font-size--huge: clamp(2.25rem, 4vw, 2.75rem);
    --wp--custom--typography--font-size--gigantic: clamp(2.75rem, 6vw, 3.25rem);
    --wp--custom--typography--font-size--colossal: clamp(3.25rem, 8vw, 6.25rem);
    --wp--custom--typography--line-height--tiny: 1.15;
    --wp--custom--typography--line-height--small: 1.2;
    --wp--custom--typography--line-height--medium: 1.4;
    --wp--custom--typography--line-height--normal: 1.6;
  }

  body {
    margin: 0;
  }

  body {
    background-color: var(--wp--preset--color--background);
    color: var(--wp--preset--color--foreground);
    font-family: var(--wp--preset--font-family--system-font);
    font-size: var(--wp--preset--font-size--medium);
    line-height: var(--wp--custom--typography--line-height--normal);
    --wp--style--block-gap: 1.5rem;
  }

  .wp-site-blocks>.alignleft {
    float: left;
    margin-right: 2em;
  }

  .wp-site-blocks>.alignright {
    float: right;
    margin-left: 2em;
  }

  .wp-site-blocks>.aligncenter {
    justify-content: center;
    margin-left: auto;
    margin-right: auto;
  }

  .wp-site-blocks>* {
    margin-top: 0;
    margin-bottom: 0;
  }

  .wp-site-blocks>*+* {
    margin-top: var(--wp--style--block-gap);
  }

  h1 {
    font-family: var(--wp--preset--font-family--source-serif-pro);
    font-size: var(--wp--custom--typography--font-size--colossal);
    font-weight: 300;
    line-height: var(--wp--custom--typography--line-height--tiny);
  }

  h2 {
    font-family: var(--wp--preset--font-family--source-serif-pro);
    font-size: var(--wp--custom--typography--font-size--gigantic);
    font-weight: 300;
    line-height: var(--wp--custom--typography--line-height--small);
  }

  h3 {
    font-family: var(--wp--preset--font-family--source-serif-pro);
    font-size: var(--wp--custom--typography--font-size--huge);
    font-weight: 300;
    line-height: var(--wp--custom--typography--line-height--tiny);
  }

  h4 {
    font-family: var(--wp--preset--font-family--source-serif-pro);
    font-size: var(--wp--preset--font-size--x-large);
    font-weight: 300;
    line-height: var(--wp--custom--typography--line-height--tiny);
  }

  h5 {
    font-family: var(--wp--preset--font-family--system-font);
    font-size: var(--wp--preset--font-size--medium);
    font-weight: 700;
    line-height: var(--wp--custom--typography--line-height--normal);
    text-transform: uppercase;
  }

  h6 {
    font-family: var(--wp--preset--font-family--system-font);
    font-size: var(--wp--preset--font-size--medium);
    font-weight: 400;
    line-height: var(--wp--custom--typography--line-height--normal);
    text-transform: uppercase;
  }

  a {
    color: var(--wp--preset--color--foreground);
  }

  .wp-block-button__link {
    background-color: var(--wp--preset--color--primary);
    border-radius: 0;
    color: var(--wp--preset--color--background);
    font-size: var(--wp--preset--font-size--medium);
  }

  .wp-block-post-title {
    font-family: var(--wp--preset--font-family--source-serif-pro);
    font-size: var(--wp--custom--typography--font-size--gigantic);
    font-weight: 300;
    line-height: var(--wp--custom--typography--line-height--tiny);
  }

  .wp-block-post-comments {
    padding-top: var(--wp--custom--spacing--small);
  }

  .wp-block-pullquote {
    border-width: 1px 0;
  }

  .wp-block-query-title {
    font-family: var(--wp--preset--font-family--source-serif-pro);
    font-size: var(--wp--custom--typography--font-size--gigantic);
    font-weight: 300;
    line-height: var(--wp--custom--typography--line-height--small);
  }

  .wp-block-quote {
    border-width: 1px;
  }

  .wp-block-site-title {
    font-family: var(--wp--preset--font-family--system-font);
    font-size: var(--wp--preset--font-size--medium);
    font-weight: normal;
    line-height: var(--wp--custom--typography--line-height--normal);
  }

  .has-black-color {
    color: var(--wp--preset--color--black) !important;
  }

  .has-cyan-bluish-gray-color {
    color: var(--wp--preset--color--cyan-bluish-gray) !important;
  }

  .has-white-color {
    color: var(--wp--preset--color--white) !important;
  }

  .has-pale-pink-color {
    color: var(--wp--preset--color--pale-pink) !important;
  }

  .has-vivid-red-color {
    color: var(--wp--preset--color--vivid-red) !important;
  }

  .has-luminous-vivid-orange-color {
    color: var(--wp--preset--color--luminous-vivid-orange) !important;
  }

  .has-luminous-vivid-amber-color {
    color: var(--wp--preset--color--luminous-vivid-amber) !important;
  }

  .has-light-green-cyan-color {
    color: var(--wp--preset--color--light-green-cyan) !important;
  }

  .has-vivid-green-cyan-color {
    color: var(--wp--preset--color--vivid-green-cyan) !important;
  }

  .has-pale-cyan-blue-color {
    color: var(--wp--preset--color--pale-cyan-blue) !important;
  }

  .has-vivid-cyan-blue-color {
    color: var(--wp--preset--color--vivid-cyan-blue) !important;
  }

  .has-vivid-purple-color {
    color: var(--wp--preset--color--vivid-purple) !important;
  }

  .has-foreground-color {
    color: var(--wp--preset--color--foreground) !important;
  }

  .has-background-color {
    color: var(--wp--preset--color--background) !important;
  }

  .has-primary-color {
    color: var(--wp--preset--color--primary) !important;
  }

  .has-secondary-color {
    color: var(--wp--preset--color--secondary) !important;
  }

  .has-tertiary-color {
    color: var(--wp--preset--color--tertiary) !important;
  }

  .has-black-background-color {
    background-color: var(--wp--preset--color--black) !important;
  }

  .has-cyan-bluish-gray-background-color {
    background-color: var(--wp--preset--color--cyan-bluish-gray) !important;
  }

  .has-white-background-color {
    background-color: var(--wp--preset--color--white) !important;
  }

  .has-pale-pink-background-color {
    background-color: var(--wp--preset--color--pale-pink) !important;
  }

  .has-vivid-red-background-color {
    background-color: var(--wp--preset--color--vivid-red) !important;
  }

  .has-luminous-vivid-orange-background-color {
    background-color: var(--wp--preset--color--luminous-vivid-orange) !important;
  }

  .has-luminous-vivid-amber-background-color {
    background-color: var(--wp--preset--color--luminous-vivid-amber) !important;
  }

  .has-light-green-cyan-background-color {
    background-color: var(--wp--preset--color--light-green-cyan) !important;
  }

  .has-vivid-green-cyan-background-color {
    background-color: var(--wp--preset--color--vivid-green-cyan) !important;
  }

  .has-pale-cyan-blue-background-color {
    background-color: var(--wp--preset--color--pale-cyan-blue) !important;
  }

  .has-vivid-cyan-blue-background-color {
    background-color: var(--wp--preset--color--vivid-cyan-blue) !important;
  }

  .has-vivid-purple-background-color {
    background-color: var(--wp--preset--color--vivid-purple) !important;
  }

  .has-foreground-background-color {
    background-color: var(--wp--preset--color--foreground) !important;
  }

  .has-background-background-color {
    background-color: var(--wp--preset--color--background) !important;
  }

  .has-primary-background-color {
    background-color: var(--wp--preset--color--primary) !important;
  }

  .has-secondary-background-color {
    background-color: var(--wp--preset--color--secondary) !important;
  }

  .has-tertiary-background-color {
    background-color: var(--wp--preset--color--tertiary) !important;
  }

  .has-black-border-color {
    border-color: var(--wp--preset--color--black) !important;
  }

  .has-cyan-bluish-gray-border-color {
    border-color: var(--wp--preset--color--cyan-bluish-gray) !important;
  }

  .has-white-border-color {
    border-color: var(--wp--preset--color--white) !important;
  }

  .has-pale-pink-border-color {
    border-color: var(--wp--preset--color--pale-pink) !important;
  }

  .has-vivid-red-border-color {
    border-color: var(--wp--preset--color--vivid-red) !important;
  }

  .has-luminous-vivid-orange-border-color {
    border-color: var(--wp--preset--color--luminous-vivid-orange) !important;
  }

  .has-luminous-vivid-amber-border-color {
    border-color: var(--wp--preset--color--luminous-vivid-amber) !important;
  }

  .has-light-green-cyan-border-color {
    border-color: var(--wp--preset--color--light-green-cyan) !important;
  }

  .has-vivid-green-cyan-border-color {
    border-color: var(--wp--preset--color--vivid-green-cyan) !important;
  }

  .has-pale-cyan-blue-border-color {
    border-color: var(--wp--preset--color--pale-cyan-blue) !important;
  }

  .has-vivid-cyan-blue-border-color {
    border-color: var(--wp--preset--color--vivid-cyan-blue) !important;
  }

  .has-vivid-purple-border-color {
    border-color: var(--wp--preset--color--vivid-purple) !important;
  }

  .has-foreground-border-color {
    border-color: var(--wp--preset--color--foreground) !important;
  }

  .has-background-border-color {
    border-color: var(--wp--preset--color--background) !important;
  }

  .has-primary-border-color {
    border-color: var(--wp--preset--color--primary) !important;
  }

  .has-secondary-border-color {
    border-color: var(--wp--preset--color--secondary) !important;
  }

  .has-tertiary-border-color {
    border-color: var(--wp--preset--color--tertiary) !important;
  }

  .has-vivid-cyan-blue-to-vivid-purple-gradient-background {
    background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;
  }

  .has-light-green-cyan-to-vivid-green-cyan-gradient-background {
    background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;
  }

  .has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background {
    background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;
  }

  .has-luminous-vivid-orange-to-vivid-red-gradient-background {
    background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;
  }

  .has-very-light-gray-to-cyan-bluish-gray-gradient-background {
    background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;
  }

  .has-cool-to-warm-spectrum-gradient-background {
    background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;
  }

  .has-blush-light-purple-gradient-background {
    background: var(--wp--preset--gradient--blush-light-purple) !important;
  }

  .has-blush-bordeaux-gradient-background {
    background: var(--wp--preset--gradient--blush-bordeaux) !important;
  }

  .has-luminous-dusk-gradient-background {
    background: var(--wp--preset--gradient--luminous-dusk) !important;
  }

  .has-pale-ocean-gradient-background {
    background: var(--wp--preset--gradient--pale-ocean) !important;
  }

  .has-electric-grass-gradient-background {
    background: var(--wp--preset--gradient--electric-grass) !important;
  }

  .has-midnight-gradient-background {
    background: var(--wp--preset--gradient--midnight) !important;
  }

  .has-vertical-secondary-to-tertiary-gradient-background {
    background: var(--wp--preset--gradient--vertical-secondary-to-tertiary) !important;
  }

  .has-vertical-secondary-to-background-gradient-background {
    background: var(--wp--preset--gradient--vertical-secondary-to-background) !important;
  }

  .has-vertical-tertiary-to-background-gradient-background {
    background: var(--wp--preset--gradient--vertical-tertiary-to-background) !important;
  }

  .has-diagonal-primary-to-foreground-gradient-background {
    background: var(--wp--preset--gradient--diagonal-primary-to-foreground) !important;
  }

  .has-diagonal-secondary-to-background-gradient-background {
    background: var(--wp--preset--gradient--diagonal-secondary-to-background) !important;
  }

  .has-diagonal-background-to-secondary-gradient-background {
    background: var(--wp--preset--gradient--diagonal-background-to-secondary) !important;
  }

  .has-diagonal-tertiary-to-background-gradient-background {
    background: var(--wp--preset--gradient--diagonal-tertiary-to-background) !important;
  }

  .has-diagonal-background-to-tertiary-gradient-background {
    background: var(--wp--preset--gradient--diagonal-background-to-tertiary) !important;
  }

  .has-small-font-size {
    font-size: var(--wp--preset--font-size--small) !important;
  }

  .has-medium-font-size {
    font-size: var(--wp--preset--font-size--medium) !important;
  }

  .has-large-font-size {
    font-size: var(--wp--preset--font-size--large) !important;
  }

  .has-x-large-font-size {
    font-size: var(--wp--preset--font-size--x-large) !important;
  }

  .has-system-font-font-family {
    font-family: var(--wp--preset--font-family--system-font) !important;
  }

  .has-source-serif-pro-font-family {
    font-family: var(--wp--preset--font-family--source-serif-pro) !important;
  }
  </style>
  <link rel="stylesheet" id="8cb199ab0-css" href="{{ asset('css/8cb199ab0.min.css')}}" media="all">
  <link rel="stylesheet" id="twentytwentytwo-style-css" href="{{ asset('css/style.css')}}" media="all">
  <style id="twentytwentytwo-style-inline-css">
  @font-face {
    font-family: 'Source Serif Pro';
    font-weight: 200 900;
    font-style: normal;
    font-stretch: normal;
    font-display: swap;
  }

  @font-face {
    font-family: 'Source Serif Pro';
    font-weight: 200 900;
    font-style: italic;
    font-stretch: normal;
    font-display: swap;
  }
  </style>
  <link rel="stylesheet" id="elementor-icons-css" href="{{ asset('css/elementor-icons.min.css')}}" media="all">
  <style id="elementor-icons-inline-css">
  .elementor-add-new-section .elementor-add-templately-promo-button {
    background-color: #5d4fff;
    background-image: url(http://elmercadomorado.com/wp-content/plugins/essential-addons-for-elementor-lite/assets/admin/images/templately/logo-icon.svg);
    background-repeat: no-repeat;
    background-position: center center;
    margin-left: 5px;
    position: relative;
    bottom: 5px;
  }
  </style>
  <link rel="stylesheet" id="elementor-frontend-css" href="{{ asset('css/frontend-lite.min.css')}}" media="all">
  <link rel="stylesheet" id="elementor-post-5-css" href="{{ asset('css/post-5.css')}}" media="all">
  <link rel="stylesheet" id="elementor-global-css" href="{{ asset('css/global.css')}}" media="all">
  <link rel="stylesheet" id="elementor-post-53-css" href="{{ asset('css/post-53.css')}}" media="all">
  <link rel="stylesheet" id="google-fonts-1-css"
    href="https://fonts.googleapis.com/css?family=Raleway%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CJosefin+Sans%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;display=auto&amp;ver=5.9.3"
    media="all">
  <link rel="stylesheet" id="elementor-icons-shared-0-css" href="{{ asset('css/fontawesome.min.css')}}" media="all">
  <link rel="stylesheet" id="elementor-icons-fa-brands-css" href="{{ asset('css/brands.min.css')}}" media="all">
  <script src="{{ asset('css/jquery.min.js')}}" id="jquery-core-js"></script>
  <script src="{{ asset('css/jquery-migrate.min.js')}}" id="jquery-migrate-js"></script>
  <link rel="https://api.w.org/" href="https://elmercadomorado.com/index.php?rest_route=/">
  <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://elmercadomorado.com/xmlrpc.php?rsd">
  <link rel="wlwmanifest" type="application/wlwmanifest+xml"
    href="http://elmercadomorado.com/wp-includes/wlwmanifest.xml">
  <meta name="generator" content="WordPress 5.9.3">
  <link rel="canonical" href="https://elmercadomorado.com/?e-landing-page=application">
  <link rel="shortlink" href="https://elmercadomorado.com/?p=53">
  <link rel="alternate" type="application/json+oembed"
    href="https://elmercadomorado.com/index.php?rest_route=%2Foembed%2F1.0%2Fembed&amp;url=https%3A%2F%2Felmercadomorado.com%2F%3Fe-landing-page%3Dapplication">
  <link rel="alternate" type="text/xml+oembed"
    href="https://elmercadomorado.com/index.php?rest_route=%2Foembed%2F1.0%2Fembed&amp;url=https%3A%2F%2Felmercadomorado.com%2F%3Fe-landing-page%3Dapplication&amp;format=xml">
  <link rel="preload"
    href="http://elmercadomorado.com/wp-content/themes/twentytwentytwo/assets/fonts/SourceSerif4Variable-Roman.ttf.woff2"
    as="font" type="font/woff2" crossorigin="">
  <link rel="icon" href="https://elmercadomorado.com/wp-content/uploads/2022/05/ICON-LOGO-FLAT-150x150.png"
    sizes="32x32">
  <link rel="icon" href="https://elmercadomorado.com/wp-content/uploads/2022/05/ICON-LOGO-FLAT.png" sizes="192x192">
  <link rel="apple-touch-icon" href="https://elmercadomorado.com/wp-content/uploads/2022/05/ICON-LOGO-FLAT.png">
  <meta name="msapplication-TileImage"
    content="https://elmercadomorado.com/wp-content/uploads/2022/05/ICON-LOGO-FLAT.png">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
</head>

<body
  class="e-landing-page-template e-landing-page-template-elementor_canvas single single-e-landing-page postid-53 single-format-standard wp-custom-logo wp-embed-responsive elementor-default elementor-template-canvas elementor-kit-5 elementor-page elementor-page-53 e--ua-blink e--ua-chrome e--ua-webkit"
  data-elementor-device-mode="desktop">
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
      <filter id="wp-duotone-dark-grayscale">
        <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
          values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix>
        <feComponentTransfer color-interpolation-filters="sRGB">
          <feFuncR type="table" tableValues="0 0.49803921568627"></feFuncR>
          <feFuncG type="table" tableValues="0 0.49803921568627"></feFuncG>
          <feFuncB type="table" tableValues="0 0.49803921568627"></feFuncB>
          <feFuncA type="table" tableValues="1 1"></feFuncA>
        </feComponentTransfer>
        <feComposite in2="SourceGraphic" operator="in"></feComposite>
      </filter>
    </defs>
  </svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
      <filter id="wp-duotone-grayscale">
        <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
          values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix>
        <feComponentTransfer color-interpolation-filters="sRGB">
          <feFuncR type="table" tableValues="0 1"></feFuncR>
          <feFuncG type="table" tableValues="0 1"></feFuncG>
          <feFuncB type="table" tableValues="0 1"></feFuncB>
          <feFuncA type="table" tableValues="1 1"></feFuncA>
        </feComponentTransfer>
        <feComposite in2="SourceGraphic" operator="in"></feComposite>
      </filter>
    </defs>
  </svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
      <filter id="wp-duotone-purple-yellow">
        <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
          values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix>
        <feComponentTransfer color-interpolation-filters="sRGB">
          <feFuncR type="table" tableValues="0.54901960784314 0.98823529411765"></feFuncR>
          <feFuncG type="table" tableValues="0 1"></feFuncG>
          <feFuncB type="table" tableValues="0.71764705882353 0.25490196078431"></feFuncB>
          <feFuncA type="table" tableValues="1 1"></feFuncA>
        </feComponentTransfer>
        <feComposite in2="SourceGraphic" operator="in"></feComposite>
      </filter>
    </defs>
  </svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
      <filter id="wp-duotone-blue-red">
        <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
          values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix>
        <feComponentTransfer color-interpolation-filters="sRGB">
          <feFuncR type="table" tableValues="0 1"></feFuncR>
          <feFuncG type="table" tableValues="0 0.27843137254902"></feFuncG>
          <feFuncB type="table" tableValues="0.5921568627451 0.27843137254902"></feFuncB>
          <feFuncA type="table" tableValues="1 1"></feFuncA>
        </feComponentTransfer>
        <feComposite in2="SourceGraphic" operator="in"></feComposite>
      </filter>
    </defs>
  </svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
      <filter id="wp-duotone-midnight">
        <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
          values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix>
        <feComponentTransfer color-interpolation-filters="sRGB">
          <feFuncR type="table" tableValues="0 0"></feFuncR>
          <feFuncG type="table" tableValues="0 0.64705882352941"></feFuncG>
          <feFuncB type="table" tableValues="0 1"></feFuncB>
          <feFuncA type="table" tableValues="1 1"></feFuncA>
        </feComponentTransfer>
        <feComposite in2="SourceGraphic" operator="in"></feComposite>
      </filter>
    </defs>
  </svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
      <filter id="wp-duotone-magenta-yellow">
        <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
          values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix>
        <feComponentTransfer color-interpolation-filters="sRGB">
          <feFuncR type="table" tableValues="0.78039215686275 1"></feFuncR>
          <feFuncG type="table" tableValues="0 0.94901960784314"></feFuncG>
          <feFuncB type="table" tableValues="0.35294117647059 0.47058823529412"></feFuncB>
          <feFuncA type="table" tableValues="1 1"></feFuncA>
        </feComponentTransfer>
        <feComposite in2="SourceGraphic" operator="in"></feComposite>
      </filter>
    </defs>
  </svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
      <filter id="wp-duotone-purple-green">
        <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
          values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix>
        <feComponentTransfer color-interpolation-filters="sRGB">
          <feFuncR type="table" tableValues="0.65098039215686 0.40392156862745"></feFuncR>
          <feFuncG type="table" tableValues="0 1"></feFuncG>
          <feFuncB type="table" tableValues="0.44705882352941 0.4"></feFuncB>
          <feFuncA type="table" tableValues="1 1"></feFuncA>
        </feComponentTransfer>
        <feComposite in2="SourceGraphic" operator="in"></feComposite>
      </filter>
    </defs>
  </svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
      <filter id="wp-duotone-blue-orange">
        <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
          values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix>
        <feComponentTransfer color-interpolation-filters="sRGB">
          <feFuncR type="table" tableValues="0.098039215686275 1"></feFuncR>
          <feFuncG type="table" tableValues="0 0.66274509803922"></feFuncG>
          <feFuncB type="table" tableValues="0.84705882352941 0.41960784313725"></feFuncB>
          <feFuncA type="table" tableValues="1 1"></feFuncA>
        </feComponentTransfer>
        <feComposite in2="SourceGraphic" operator="in"></feComposite>
      </filter>
    </defs>
  </svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
      <filter id="wp-duotone-foreground-and-background">
        <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
          values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix>
        <feComponentTransfer color-interpolation-filters="sRGB">
          <feFuncR type="table" tableValues="0 1"></feFuncR>
          <feFuncG type="table" tableValues="0 1"></feFuncG>
          <feFuncB type="table" tableValues="0 1"></feFuncB>
          <feFuncA type="table" tableValues="1 1"></feFuncA>
        </feComponentTransfer>
        <feComposite in2="SourceGraphic" operator="in"></feComposite>
      </filter>
    </defs>
  </svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
      <filter id="wp-duotone-foreground-and-secondary">
        <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
          values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix>
        <feComponentTransfer color-interpolation-filters="sRGB">
          <feFuncR type="table" tableValues="0 1"></feFuncR>
          <feFuncG type="table" tableValues="0 0.88627450980392"></feFuncG>
          <feFuncB type="table" tableValues="0 0.78039215686275"></feFuncB>
          <feFuncA type="table" tableValues="1 1"></feFuncA>
        </feComponentTransfer>
        <feComposite in2="SourceGraphic" operator="in"></feComposite>
      </filter>
    </defs>
  </svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
      <filter id="wp-duotone-foreground-and-tertiary">
        <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
          values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix>
        <feComponentTransfer color-interpolation-filters="sRGB">
          <feFuncR type="table" tableValues="0 0.96470588235294"></feFuncR>
          <feFuncG type="table" tableValues="0 0.96470588235294"></feFuncG>
          <feFuncB type="table" tableValues="0 0.96470588235294"></feFuncB>
          <feFuncA type="table" tableValues="1 1"></feFuncA>
        </feComponentTransfer>
        <feComposite in2="SourceGraphic" operator="in"></feComposite>
      </filter>
    </defs>
  </svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
      <filter id="wp-duotone-primary-and-background">
        <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
          values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix>
        <feComponentTransfer color-interpolation-filters="sRGB">
          <feFuncR type="table" tableValues="0.10196078431373 1"></feFuncR>
          <feFuncG type="table" tableValues="0.27058823529412 1"></feFuncG>
          <feFuncB type="table" tableValues="0.28235294117647 1"></feFuncB>
          <feFuncA type="table" tableValues="1 1"></feFuncA>
        </feComponentTransfer>
        <feComposite in2="SourceGraphic" operator="in"></feComposite>
      </filter>
    </defs>
  </svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
      <filter id="wp-duotone-primary-and-secondary">
        <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
          values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix>
        <feComponentTransfer color-interpolation-filters="sRGB">
          <feFuncR type="table" tableValues="0.10196078431373 1"></feFuncR>
          <feFuncG type="table" tableValues="0.27058823529412 0.88627450980392"></feFuncG>
          <feFuncB type="table" tableValues="0.28235294117647 0.78039215686275"></feFuncB>
          <feFuncA type="table" tableValues="1 1"></feFuncA>
        </feComponentTransfer>
        <feComposite in2="SourceGraphic" operator="in"></feComposite>
      </filter>
    </defs>
  </svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none"
    style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;">
    <defs>
      <filter id="wp-duotone-primary-and-tertiary">
        <feColorMatrix color-interpolation-filters="sRGB" type="matrix"
          values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "></feColorMatrix>
        <feComponentTransfer color-interpolation-filters="sRGB">
          <feFuncR type="table" tableValues="0.10196078431373 0.96470588235294"></feFuncR>
          <feFuncG type="table" tableValues="0.27058823529412 0.96470588235294"></feFuncG>
          <feFuncB type="table" tableValues="0.28235294117647 0.96470588235294"></feFuncB>
          <feFuncA type="table" tableValues="1 1"></feFuncA>
        </feComponentTransfer>
        <feComposite in2="SourceGraphic" operator="in"></feComposite>
      </filter>
    </defs>
  </svg>
  <div data-elementor-type="landing-page" data-elementor-id="53" class="elementor elementor-53">
    <section
      class="elementor-section elementor-top-section elementor-element elementor-element-2b319a67 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
      data-id="2b319a67" data-element_type="section">
      <div class="elementor-container elementor-column-gap-default">
        <div
          class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5f0b831c"
          data-id="5f0b831c" data-element_type="column">
          <div class="elementor-widget-wrap elementor-element-populated">
            <div class="elementor-element elementor-element-7e0fc036 elementor-widget elementor-widget-spacer"
              data-id="7e0fc036" data-element_type="widget" data-widget_type="spacer.default">
              <div class="elementor-widget-container">
                <style>
                /*! elementor - v3.6.5 - 27-04-2022 */
                .e-container.e-container--row .elementor-spacer-inner {
                  width: var(--spacer-size)
                }

                .e-container.e-container--column .elementor-spacer-inner,
                .elementor-column .elementor-spacer-inner {
                  height: var(--spacer-size)
                }
                </style>
                <div class="elementor-spacer">
                  <div class="elementor-spacer-inner"></div>
                </div>
              </div>
            </div>
            <div class="elementor-element elementor-element-a9f9b2 elementor-widget elementor-widget-image"
              data-id="a9f9b2" data-element_type="widget" data-widget_type="image.default">
              <div class="elementor-widget-container">
                <style>
                /*! elementor - v3.6.5 - 27-04-2022 */
                .elementor-widget-image {
                  text-align: center
                }

                .elementor-widget-image a {
                  display: inline-block
                }

                .elementor-widget-image a img[src$=".svg"] {
                  width: 48px
                }

                .elementor-widget-image img {
                  vertical-align: middle;
                  display: inline-block
                }
                </style> <img width="408" height="146"
                  src="https://elmercadomorado.com/wp-content/uploads/2022/05/Web-site.png"
                  class="attachment-large size-large" alt="" loading="lazy"
                  srcset="https://elmercadomorado.com/wp-content/uploads/2022/05/Web-site.png 408w, https://elmercadomorado.com/wp-content/uploads/2022/05/Web-site-300x107.png 300w"
                  sizes="(max-width: 408px) 100vw, 408px">
              </div>
            </div>
            <div
              class="elementor-element elementor-element-66491706 elementor-aspect-ratio-169 elementor-widget elementor-widget-video"
              data-id="66491706" data-element_type="widget"
              data-settings="{&quot;youtube_url&quot;:&quot;https:\/\/youtu.be\/mEliSdpweCg&quot;,&quot;video_type&quot;:&quot;youtube&quot;,&quot;controls&quot;:&quot;yes&quot;,&quot;aspect_ratio&quot;:&quot;169&quot;}"
              data-widget_type="video.default">
              <div class="elementor-widget-container">
                <style>
                /*! elementor - v3.6.5 - 27-04-2022 */
                .elementor-widget-video .elementor-widget-container {
                  overflow: hidden;
                  -webkit-transform: translateZ(0);
                  transform: translateZ(0)
                }

                .elementor-widget-video .elementor-open-inline .elementor-custom-embed-image-overlay {
                  position: absolute;
                  top: 0;
                  left: 0;
                  width: 100%;
                  height: 100%;
                  background-size: cover;
                  background-position: 50%
                }

                .elementor-widget-video .elementor-custom-embed-image-overlay {
                  cursor: pointer;
                  text-align: center
                }

                .elementor-widget-video .elementor-custom-embed-image-overlay:hover .elementor-custom-embed-play i {
                  opacity: 1
                }

                .elementor-widget-video .elementor-custom-embed-image-overlay img {
                  display: block;
                  width: 100%
                }

                .elementor-widget-video .e-hosted-video .elementor-video {
                  -o-object-fit: cover;
                  object-fit: cover
                }
                </style>
                <div class="elementor-wrapper elementor-fit-aspect-ratio elementor-open-inline">
                  <iframe class="elementor-video" frameborder="0" allowfullscreen="1"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    title="YouTube video player" width="640" height="360"
                    src="https://www.youtube.com/embed/mEliSdpweCg?controls=1&amp;rel=0&amp;playsinline=0&amp;modestbranding=0&amp;autoplay=0&amp;enablejsapi=1&amp;origin=http%3A%2F%2Felmercadomorado.com&amp;widgetid=1"
                    id="widget2"></iframe>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section
      class="elementor-section elementor-top-section elementor-element elementor-element-2839a31c elementor-section-boxed elementor-section-height-default elementor-section-height-default"
      data-id="2839a31c" data-element_type="section">
      <div class="elementor-container elementor-column-gap-default">
        <div
          class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-4fb918a6"
          data-id="4fb918a6" data-element_type="column">
          <div class="elementor-widget-wrap elementor-element-populated">
            <div class="elementor-element elementor-element-12500c60 elementor-widget elementor-widget-text-editor"
              data-id="12500c60" data-element_type="widget" data-widget_type="text-editor.default">
              <div class="elementor-widget-container">
                <style>
                /*! elementor - v3.6.5 - 27-04-2022 */
                .elementor-widget-text-editor.elementor-drop-cap-view-stacked .elementor-drop-cap {
                  background-color: #818a91;
                  color: #fff
                }

                .elementor-widget-text-editor.elementor-drop-cap-view-framed .elementor-drop-cap {
                  color: #818a91;
                  border: 3px solid;
                  background-color: transparent
                }

                .elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap {
                  margin-top: 8px
                }

                .elementor-widget-text-editor:not(.elementor-drop-cap-view-default) .elementor-drop-cap-letter {
                  width: 1em;
                  height: 1em
                }

                .elementor-widget-text-editor .elementor-drop-cap {
                  float: left;
                  text-align: center;
                  line-height: 1;
                  font-size: 50px
                }

                .elementor-widget-text-editor .elementor-drop-cap-letter {
                  display: inline-block
                }
                </style>
                <h1>Work with different businesses all across North America!</h1>
              </div>
            </div>
            <div class="elementor-element elementor-element-42619be6 elementor-widget elementor-widget-text-editor"
              data-id="42619be6" data-element_type="widget" data-widget_type="text-editor.default">
              <div class="elementor-widget-container">
                <p>Hospitals, Plumbing companies, Real Estate, Apartment complexes, Dr.'s offices, Gas monitoring, and
                  Attorneys; are just some of the lines of businesses we serve.</p>
                <p>Every day thousands of customers and patients call these businesses either to schedule an
                  appointment, discuss billing or handle any other urgent (or not so urgent) matter. <strong>So what
                    happens to these calls when their offices aren't available (lunch time, closing hours,
                    meetings)?</strong>
                  Well we take care of them! As an answering service representative, you will receive these calls and
                  either take a message or assist the callers by following specific procedures and prompts that you will
                  learn during training.
                </p>
                <p>You can find more information about the job below!</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section
      class="elementor-section elementor-top-section elementor-element elementor-element-39feb1d0 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
      data-id="39feb1d0" data-element_type="section">
      <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-73bc88c"
          data-id="73bc88c" data-element_type="column">
          <div class="elementor-widget-wrap elementor-element-populated">
            <div
              class="elementor-element elementor-element-afac621 elementor-tabs-view-horizontal elementor-widget elementor-widget-tabs animated fadeIn"
              data-id="afac621" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}"
              data-widget_type="tabs.default">
              <div class="elementor-widget-container">
                <style>
                /*! elementor - v3.6.5 - 27-04-2022 */
                .elementor-widget-tabs.elementor-tabs-view-vertical .elementor-tabs-wrapper {
                  width: 25%;
                  -ms-flex-negative: 0;
                  flex-shrink: 0
                }

                .elementor-widget-tabs.elementor-tabs-view-vertical .elementor-tab-desktop-title.elementor-active {
                  border-right-style: none
                }

                .elementor-widget-tabs.elementor-tabs-view-vertical .elementor-tab-desktop-title.elementor-active:after,
                .elementor-widget-tabs.elementor-tabs-view-vertical .elementor-tab-desktop-title.elementor-active:before {
                  height: 999em;
                  width: 0;
                  right: 0;
                  border-right-style: solid
                }

                .elementor-widget-tabs.elementor-tabs-view-vertical .elementor-tab-desktop-title.elementor-active:before {
                  top: 0;
                  -webkit-transform: translateY(-100%);
                  -ms-transform: translateY(-100%);
                  transform: translateY(-100%)
                }

                .elementor-widget-tabs.elementor-tabs-view-vertical .elementor-tab-desktop-title.elementor-active:after {
                  top: 100%
                }

                .elementor-widget-tabs.elementor-tabs-view-horizontal .elementor-tab-desktop-title {
                  display: table-cell
                }

                .elementor-widget-tabs.elementor-tabs-view-horizontal .elementor-tab-desktop-title.elementor-active {
                  border-bottom-style: none
                }

                .elementor-widget-tabs.elementor-tabs-view-horizontal .elementor-tab-desktop-title.elementor-active:after,
                .elementor-widget-tabs.elementor-tabs-view-horizontal .elementor-tab-desktop-title.elementor-active:before {
                  bottom: 0;
                  height: 0;
                  width: 999em;
                  border-bottom-style: solid
                }

                .elementor-widget-tabs.elementor-tabs-view-horizontal .elementor-tab-desktop-title.elementor-active:before {
                  right: 100%
                }

                .elementor-widget-tabs.elementor-tabs-view-horizontal .elementor-tab-desktop-title.elementor-active:after {
                  left: 100%
                }

                .elementor-widget-tabs .elementor-tab-content,
                .elementor-widget-tabs .elementor-tab-title,
                .elementor-widget-tabs .elementor-tab-title:after,
                .elementor-widget-tabs .elementor-tab-title:before,
                .elementor-widget-tabs .elementor-tabs-content-wrapper {
                  border: 1px #d4d4d4
                }

                .elementor-widget-tabs .elementor-tabs {
                  text-align: left
                }

                .elementor-widget-tabs .elementor-tabs-wrapper {
                  overflow: hidden
                }

                .elementor-widget-tabs .elementor-tab-title {
                  cursor: pointer;
                  outline: var(--focus-outline, none)
                }

                .elementor-widget-tabs .elementor-tab-desktop-title {
                  position: relative;
                  padding: 20px 25px;
                  font-weight: 700;
                  line-height: 1;
                  border: solid transparent
                }

                .elementor-widget-tabs .elementor-tab-desktop-title.elementor-active {
                  border-color: #d4d4d4
                }

                .elementor-widget-tabs .elementor-tab-desktop-title.elementor-active:after,
                .elementor-widget-tabs .elementor-tab-desktop-title.elementor-active:before {
                  display: block;
                  content: "";
                  position: absolute
                }

                .elementor-widget-tabs .elementor-tab-mobile-title {
                  padding: 10px;
                  cursor: pointer
                }

                .elementor-widget-tabs .elementor-tab-content {
                  padding: 20px;
                  display: none
                }

                @media (max-width:767px) {

                  .elementor-tabs .elementor-tab-content,
                  .elementor-tabs .elementor-tab-title {
                    border-style: solid solid none
                  }

                  .elementor-tabs .elementor-tabs-wrapper {
                    display: none
                  }

                  .elementor-tabs .elementor-tabs-content-wrapper {
                    border-bottom-style: solid
                  }

                  .elementor-tabs .elementor-tab-content {
                    padding: 10px
                  }
                }

                @media (min-width:768px) {
                  .elementor-widget-tabs.elementor-tabs-view-vertical .elementor-tabs {
                    display: -webkit-box;
                    display: -ms-flexbox;
                    display: flex
                  }

                  .elementor-widget-tabs.elementor-tabs-view-vertical .elementor-tabs-wrapper {
                    -webkit-box-orient: vertical;
                    -webkit-box-direction: normal;
                    -ms-flex-direction: column;
                    flex-direction: column
                  }

                  .elementor-widget-tabs.elementor-tabs-view-vertical .elementor-tabs-content-wrapper {
                    -webkit-box-flex: 1;
                    -ms-flex-positive: 1;
                    flex-grow: 1;
                    border-style: solid solid solid none
                  }

                  .elementor-widget-tabs.elementor-tabs-view-horizontal .elementor-tab-content {
                    border-style: none solid solid
                  }

                  .elementor-widget-tabs.elementor-tabs-alignment-center .elementor-tabs-wrapper,
                  .elementor-widget-tabs.elementor-tabs-alignment-end .elementor-tabs-wrapper,
                  .elementor-widget-tabs.elementor-tabs-alignment-stretch .elementor-tabs-wrapper {
                    display: -webkit-box;
                    display: -ms-flexbox;
                    display: flex
                  }

                  .elementor-widget-tabs.elementor-tabs-alignment-center .elementor-tabs-wrapper {
                    -webkit-box-pack: center;
                    -ms-flex-pack: center;
                    justify-content: center
                  }

                  .elementor-widget-tabs.elementor-tabs-alignment-end .elementor-tabs-wrapper {
                    -webkit-box-pack: end;
                    -ms-flex-pack: end;
                    justify-content: flex-end
                  }

                  .elementor-widget-tabs.elementor-tabs-alignment-stretch.elementor-tabs-view-horizontal .elementor-tab-title {
                    width: 100%
                  }

                  .elementor-widget-tabs.elementor-tabs-alignment-stretch.elementor-tabs-view-vertical .elementor-tab-title {
                    height: 100%
                  }

                  .elementor-tabs .elementor-tab-mobile-title {
                    display: none
                  }
                }
                </style>
                <div class="elementor-tabs">
                  <div class="elementor-tabs-wrapper" role="tablist">
                    <div id="elementor-tab-title-1841" class="elementor-tab-title elementor-tab-desktop-title"
                      onclick="show_hide(1841)">Requirements</div>
                    <div id="elementor-tab-title-1842" class="elementor-tab-title elementor-tab-desktop-title"
                      onclick="show_hide(1842)">Job Description</div>
                    <div id="elementor-tab-title-1843"
                      class="elementor-tab-title elementor-tab-desktop-title elementor-active"
                      onclick="show_hide(1843)">Perks</div>
                  </div>
                  <div class="elementor-tabs-content-wrapper" role="tablist" aria-orientation="vertical">
                    <div id="elementor-1841" class="elementor-tab-title elementor-tab-mobile-title"
                      onclick="show_hide(1841)">
                      Requirements</div>
                    <div id="elementor-tab-content-1841" class="elementor-tab-content elementor-clearfix" data-tab="1"
                      role="tabpanel" aria-labelledby="elementor-tab-title-1841" tabindex="0" style="display: none;"
                      hidden="hidden">
                      <ul>
                        <li dir="ltr" role="presentation">
                          <p>You must be 18 or older to apply!</p>
                        </li>
                        <li dir="ltr" role="presentation">
                          <p>A high-school diploma or a GED is required to become a dedicated answering service
                            representative.</p>
                        </li>
                        <li dir="ltr" role="presentation">
                          <p>Customer service experience is preferred, however not necessary.</p>
                        </li>
                        <li dir="ltr" role="presentation">
                          <p>Good typing, computer, and organization skills are required.</p>
                        </li>
                        <li dir="ltr" role="presentation">
                          <p>We are looking for people who are comfortable with multitasking and have an understanding
                            of phone etiquette.</p>
                        </li>
                        <li dir="ltr" role="presentation">
                          <p>High intermediate to advanced verbal and written communication skills in English.</p>
                        </li>
                        <li dir="ltr" role="presentation">
                          <p>Fluent Spanish is a plus!</p>
                        </li>
                        <li dir="ltr" role="presentation">
                          <p>Familiarized with technology!</p>
                        </li>
                        <li dir="ltr" role="presentation">
                          <p>Punctuality is key!</p>
                        </li>
                      </ul>
                    </div>
                    <div id="elementor-1842" class="elementor-tab-title elementor-tab-mobile-title"
                      onclick="show_hide(1842)">Job
                      Description</div>
                    <div id="elementor-tab-content-1842" class="elementor-tab-content elementor-clearfix" data-tab="2"
                      role="tabpanel" aria-labelledby="elementor-tab-title-1842" tabindex="0" style="display: none;"
                      hidden="hidden">
                      <ul>
                        <li aria-level="1">
                          <p>5 days a week</p>
                        </li>
                        <li aria-level="1">
                          <p>Usually an 8 hour and 30 minute (for lunch) shift</p>
                        </li>
                        <li aria-level="1">
                          <p>We have 3 shifts available: AM, PM and OVERNIGHT</p>
                        </li>
                        <li aria-level="1">
                          <p>Work is from home for the following locations:</p>

                          <ul style="list-style-type:circle;">
                            <li>Cancún</li>
                            <li>Ciudad de Campeche</li>
                            <li>Playa del Carmen</li>
                          </ul>
                        </li>
                        <li aria-level="1">
                          <p>If you're in Merida, the job is in office.</p>
                        </li>
                        <li aria-level="1">
                          <p>We provide all the equipment.</p>
                        </li>
                        <li aria-level="1">
                          <p>If you're applying for an at home position, you must meet the following internet
                            requirements: 50 mbps for download, 6 mbps for upload.</p>
                        </li>
                      </ul>
                    </div>
                    <div id="elementor-1843" class="elementor-tab-title elementor-tab-mobile-title elementor-active"
                      onclick="show_hide(1843)">Perks</div>
                    <div id="elementor-tab-content-1843"
                      class="elementor-tab-content elementor-clearfix elementor-active" data-tab="3" role="tabpanel"
                      aria-labelledby="elementor-tab-title-1843" tabindex="0" style="display: block;">
                      <ul>
                        <li aria-level="1">
                          <p>Salary: $16,000 MXN a month.</p>
                        </li>
                        <li aria-level="1">
                          <p>Monthly Bonuses.</p>
                        </li>
                        <li aria-level="1">
                          <p>Continuous and Paid training.</p>
                        </li>
                        <li aria-level="1">
                          <p>Career plans and professional growth with Dedicated People.</p>
                        </li>
                        <li aria-level="1">
                          <p>Free consults with our psychologists.</p>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section
      class="elementor-section elementor-top-section elementor-element elementor-element-43d6fff0 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
      data-id="43d6fff0" data-element_type="section">
      <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-662259aa"
          data-id="662259aa" data-element_type="column">
          <div class="elementor-widget-wrap elementor-element-populated">
            <div class="elementor-element elementor-element-8018d2a elementor-widget elementor-widget-lottie"
              data-id="8018d2a" data-element_type="widget" data-widget_type="lottie.default">
              <div class="elementor-widget-container">
                <div class="animentor-lottie-widget">
                  <lottie-player src="https://assets9.lottiefiles.com/packages/lf20_1snz9wmy.json"
                    background="transparent" speed="1" style="width: 300px; height: 300px;" hover loop autoplay>
                  </lottie-player>
                  <defs>
                    <clipPath id="__lottie_element_2">
                      <rect width="360" height="360" x="0" y="0"></rect>
                    </clipPath>
                  </defs>
                  <g clip-path="url(#__lottie_element_2)">
                    <g transform="matrix(0,0,0,0,179,249.31100463867188)" opacity="1" style="display: block;">
                      <g opacity="1" transform="matrix(1,0,0,1,53.595001220703125,29.708999633789062)">
                        <path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10"
                          stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                          d=" M42.79600143432617,27.02899932861328 C42.79600143432617,27.02899932861328 -42.79399871826172,27.02899932861328 -42.79399871826172,27.02899932861328 C-46.808998107910156,27.02899932861328 -50.09600067138672,23.743999481201172 -50.09600067138672,19.729000091552734 C-50.09600067138672,19.729000091552734 -50.09600067138672,-19.729000091552734 -50.09600067138672,-19.729000091552734 C-50.09600067138672,-23.7450008392334 -46.808998107910156,-27.02899932861328 -42.79399871826172,-27.02899932861328 C-42.79399871826172,-27.02899932861328 42.79600143432617,-27.02899932861328 42.79600143432617,-27.02899932861328 C46.81100082397461,-27.02899932861328 50.09600067138672,-23.7450008392334 50.09600067138672,-19.729000091552734 C50.09600067138672,-19.729000091552734 50.09600067138672,19.729000091552734 50.09600067138672,19.729000091552734 C50.09600067138672,23.743999481201172 46.81100082397461,27.02899932861328 42.79600143432617,27.02899932861328z">
                        </path>
                      </g>
                      <g opacity="1" transform="matrix(1,0,0,1,56.231998443603516,30.009000778198242)">
                        <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10"
                          stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                          d=" M7.480000019073486,-10.925999641418457 C7.480000019073486,-10.925999641418457 2.5290000438690186,-15.095000267028809 -3.6630001068115234,-14.095999717712402 C-9.486000061035156,-13.156999588012695 -10.17199993133545,-9.220000267028809 -10.092000007629395,-7.249000072479248 C-10.069000244140625,-6.669000148773193 -10.241999626159668,-1.871000051498413 0.6859999895095825,0.8500000238418579 C11.45300006866455,3.5309998989105225 7.48799991607666,12.345999717712402 2.5139999389648438,13.795999526977539 C-1.937999963760376,15.095000267028809 -7.193999767303467,13.892999649047852 -11.45199966430664,10.08899974822998">
                        </path>
                      </g>
                      <g opacity="1" transform="matrix(1,0,0,1,54.56399917602539,30.163999557495117)">
                        <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10"
                          stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                          d=" M-0.24899999797344208,-19.25 C-0.24899999797344208,-19.25 0.24899999797344208,19.25 0.24899999797344208,19.25">
                        </path>
                      </g>
                      <g opacity="1" transform="matrix(1,0,0,1,10.772000312805176,9.652999877929688)">
                        <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10"
                          stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                          d=" M5.684000015258789,-7.013000011444092 C5.684000015258789,-7.013000011444092 7.271999835968018,4.8460001945495605 -7.2729997634887695,7.013000011444092">
                        </path>
                      </g>
                      <g opacity="1" transform="matrix(1,0,0,1,96.41799926757812,9.692999839782715)">
                        <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10"
                          stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                          d=" M-5.683000087738037,-7.013000011444092 C-5.683000087738037,-7.013000011444092 -7.271999835968018,4.8470001220703125 7.271999835968018,7.013000011444092">
                        </path>
                      </g>
                      <g opacity="1" transform="matrix(1,0,0,1,96.41799926757812,49.435001373291016)">
                        <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10"
                          stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                          d=" M-5.683000087738037,7.013000011444092 C-5.683000087738037,7.013000011444092 -7.271999835968018,-4.8470001220703125 7.271999835968018,-7.013000011444092">
                        </path>
                      </g>
                      <g opacity="1" transform="matrix(1,0,0,1,10.772000312805176,49.39500045776367)">
                        <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="10"
                          stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                          d=" M5.684000015258789,7.013000011444092 C5.684000015258789,7.013000011444092 7.271999835968018,-4.8460001945495605 -7.2729997634887695,-7.013000011444092">
                        </path>
                      </g>
                    </g>
                    <g transform="matrix(1,0,0,1,200.91200256347656,123.5)" opacity="1" style="display: none;">
                      <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                        <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                        <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                          stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="2" d="M0 0"></path>
                      </g>
                    </g>
                    <g transform="matrix(1,0,0,1,283.65899658203125,200.5749969482422)" opacity="1"
                      style="display: none;">
                      <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                        <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                        <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                          stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="2"
                          d=" M-24.54400062561035,20 C-32.62099838256836,20 -44.82600021362305,20 -57.185001373291016,20">
                        </path>
                      </g>
                    </g>
                    <g transform="matrix(1,0,0,1,177.90399169921875,161.5)" opacity="1" style="display: none;">
                      <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                        <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                        <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                          stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="2"
                          d=" M-63.327999114990234,20 C-69.01399993896484,20 -74.59300231933594,20 -79.6709976196289,20">
                        </path>
                      </g>
                    </g>
                    <g transform="matrix(1,0,0,1,311.90399169921875,148.51600646972656)" opacity="1"
                      style="display: none;">
                      <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                        <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                        <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                          stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="2" d="M0 0"></path>
                      </g>
                    </g>
                    <g transform="matrix(1,0,0,1,321.90399169921875,180)" opacity="1" style="display: none;">
                      <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                        <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                        <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                          stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="2" d="M0 0"></path>
                      </g>
                    </g>
                    <g transform="matrix(0.9425081610679626,0,0,0.9425081610679626,171.3694610595703,186.23704528808594)"
                      opacity="1" style="display: none;">
                      <g opacity="1" transform="matrix(1,0,0,1,8.095999717712402,-2.9040000438690186)">
                        <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                        <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                          stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                          d=" M0,-60.09550094604492 C33.16670608520508,-60.09550094604492 60.09550094604492,-33.16670608520508 60.09550094604492,0 C60.09550094604492,33.16670608520508 33.16670608520508,60.09550094604492 0,60.09550094604492 C-33.16670608520508,60.09550094604492 -60.09550094604492,33.16670608520508 -60.09550094604492,0 C-60.09550094604492,-33.16670608520508 -33.16670608520508,-60.09550094604492 0,-60.09550094604492z">
                        </path>
                      </g>
                    </g>
                    <g transform="matrix(1.1659327745437622,0,0,1.1659327745437622,194.74009704589844,216.7290802001953)"
                      opacity="1" style="display: none;">
                      <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                        <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                        <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                          stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="6"
                          d=" M-44.5,-32 C-44.5,-32 -22,-10 -22,-10 C-22,-10 17.5,-47 17.5,-47"></path>
                      </g>
                    </g>
                    <g transform="matrix(1,0,0,1,180,180)" opacity="1" style="display: none;">
                      <g opacity="1" transform="matrix(1,0,0,1,-0.8399999737739563,2.2890000343322754)">
                        <g opacity="1" transform="matrix(0.8660253882408142,-0.5,0.5,0.8660253882408142,0,0)">
                          <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                          <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                            stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                            d=" M-3,-66.36100006103516 C-3,-66.46399688720703 -3,-66.57099914550781 -3,-66.68199920654297">
                          </path>
                        </g>
                        <g opacity="1" transform="matrix(0.5,-0.8660253882408142,0.8660253882408142,0.5,0,0)">
                          <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                          <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                            stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                            d=" M-3,-66.36100006103516 C-3,-66.46399688720703 -3,-66.57099914550781 -3,-66.68199920654297">
                          </path>
                        </g>
                        <g opacity="1" transform="matrix(0,-1,1,0,0,0)">
                          <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                          <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                            stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                            d=" M-3,-66.36100006103516 C-3,-66.46399688720703 -3,-66.57099914550781 -3,-66.68199920654297">
                          </path>
                        </g>
                        <g opacity="1" transform="matrix(-0.5,-0.8660253882408142,0.8660253882408142,-0.5,0,0)">
                          <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                          <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                            stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                            d=" M-3,-66.36100006103516 C-3,-66.46399688720703 -3,-66.57099914550781 -3,-66.68199920654297">
                          </path>
                        </g>
                        <g opacity="1" transform="matrix(-0.8660253882408142,-0.5,0.5,-0.8660253882408142,0,0)">
                          <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                          <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                            stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                            d=" M-3,-66.36100006103516 C-3,-66.46399688720703 -3,-66.57099914550781 -3,-66.68199920654297">
                          </path>
                        </g>
                        <g opacity="1" transform="matrix(-1,0,0,-1,0,0)">
                          <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                          <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                            stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                            d=" M-3,-66.36100006103516 C-3,-66.46399688720703 -3,-66.57099914550781 -3,-66.68199920654297">
                          </path>
                        </g>
                        <g opacity="1" transform="matrix(-0.8660253882408142,0.5,-0.5,-0.8660253882408142,0,0)">
                          <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                          <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                            stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                            d=" M-3,-66.36100006103516 C-3,-66.46399688720703 -3,-66.57099914550781 -3,-66.68199920654297">
                          </path>
                        </g>
                        <g opacity="1" transform="matrix(-0.5,0.8660253882408142,-0.8660253882408142,-0.5,0,0)">
                          <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                          <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                            stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                            d=" M-3,-66.36100006103516 C-3,-66.46399688720703 -3,-66.57099914550781 -3,-66.68199920654297">
                          </path>
                        </g>
                        <g opacity="1" transform="matrix(0,1,-1,0,0,0)">
                          <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                          <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                            stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                            d=" M-3,-66.36100006103516 C-3,-66.46399688720703 -3,-66.57099914550781 -3,-66.68199920654297">
                          </path>
                        </g>
                        <g opacity="1" transform="matrix(0.5,0.8660253882408142,-0.8660253882408142,0.5,0,0)">
                          <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                          <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                            stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                            d=" M-3,-66.36100006103516 C-3,-66.46399688720703 -3,-66.57099914550781 -3,-66.68199920654297">
                          </path>
                        </g>
                        <g opacity="1" transform="matrix(0.8660253882408142,0.5,-0.5,0.8660253882408142,0,0)">
                          <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                          <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                            stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                            d=" M-3,-66.36100006103516 C-3,-66.46399688720703 -3,-66.57099914550781 -3,-66.68199920654297">
                          </path>
                        </g>
                        <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                          <path fill="rgb(255,0,0)" fill-opacity="1" d="M0 0"></path>
                          <path stroke-linecap="round" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"
                            stroke="rgb(64,217,192)" stroke-opacity="1" stroke-width="4"
                            d=" M-3,-66.36100006103516 C-3,-66.46399688720703 -3,-66.57099914550781 -3,-66.68199920654297">
                          </path>
                        </g>
                      </g>
                    </g>
                  </g>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-36e4c919"
          data-id="36e4c919" data-element_type="column">
          <div class="elementor-widget-wrap elementor-element-populated">
            <div
              class="elementor-element elementor-element-4649176 eael-dual-header-content-align-left elementor-widget elementor-widget-eael-dual-color-header"
              data-id="4649176" data-element_type="widget" data-widget_type="eael-dual-color-header.default">
              <div class="elementor-widget-container">

                <div class="eael-dual-header">
                  <h2 class="title"><span class="lead solid-color">You can earn more</span> <span>by earning high
                      quality bonuses!</span></h2>
                  <span class="subtext"></span>
                  <span class="eael-dch-svg-icon"></span>
                </div>




              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section
      class="elementor-section elementor-top-section elementor-element elementor-element-38c88509 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
      data-id="38c88509" data-element_type="section">
      <div class="elementor-container elementor-column-gap-default">
        <div
          class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-6adfd34c"
          data-id="6adfd34c" data-element_type="column">
          <div class="elementor-widget-wrap elementor-element-populated">
            <div class="elementor-element elementor-element-ec7b063 elementor-widget elementor-widget-spacer"
              data-id="ec7b063" data-element_type="widget" data-widget_type="spacer.default">
              <div class="elementor-widget-container">
                <div class="elementor-spacer">
                  <div class="elementor-spacer-inner"></div>
                </div>
              </div>
            </div>
            <div
              class="elementor-element elementor-element-3a5e2636 elementor-align-center elementor-widget elementor-widget-button"
              data-id="3a5e2636" data-element_type="widget" data-widget_type="button.default">
              <div class="elementor-widget-container">
                <div class="elementor-button-wrapper">
                  <a href="https://bit.ly/DP-Onlineapplication"
                    class="elementor-button-link elementor-button elementor-size-xl elementor-animation-grow"
                    role="button">
                    <span class="elementor-button-content-wrapper">
                      <span class="elementor-button-text">Apply now!</span>
                    </span>
                  </a>
                </div>
              </div>
            </div>
            <div class="elementor-element elementor-element-144c90d2 elementor-widget elementor-widget-spacer"
              data-id="144c90d2" data-element_type="widget" data-widget_type="spacer.default">
              <div class="elementor-widget-container">
                <div class="elementor-spacer">
                  <div class="elementor-spacer-inner"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section
      class="elementor-section elementor-top-section elementor-element elementor-element-5f4ea592 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
      data-id="5f4ea592" data-element_type="section">
      <div class="elementor-background-overlay"></div>
      <div class="elementor-container elementor-column-gap-default">
        <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-fc2fa76"
          data-id="fc2fa76" data-element_type="column">
          <div class="elementor-widget-wrap elementor-element-populated">
            <div class="elementor-element elementor-element-3934aa01 elementor-widget elementor-widget-text-editor"
              data-id="3934aa01" data-element_type="widget" data-widget_type="text-editor.default">
              <div class="elementor-widget-container">
                <p><a
                    href="https://www.google.com/maps/place/2851+Johnston+St+%23543,+Lafayette,+LA+70503,+EE.+UU./@30.2049406,-92.0421944,17z/data=!3m1!4b1!4m5!3m4!1s0x86249c445c5c2665:0x59877b417c69cf36!8m2!3d30.204936!4d-92.0400057?hl=es">Main
                    office: 2851 Johnston Street #543 Lafayette</a></p>
                <p><a
                    href="https://www.google.com/maps/place/Calle+20+212A,+Col.+M%C3%A9xico,+M%C3%A9xico+Oriente,+97137+M%C3%A9rida,+Yuc./@21.000716,-89.604403,17z/data=!4m5!3m4!1s0x8f5676caff21f66b:0x8acc9bd0c995052!8m2!3d21.0007117!4d-89.6042117?hl=es">Remote
                    Office: Calle 20 212A Col. México, México Oriente 97137 Mérida, Yuc.</a></p>
              </div>
            </div>
          </div>
        </div>
        <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-230bce3d"
          data-id="230bce3d" data-element_type="column">
          <div class="elementor-widget-wrap elementor-element-populated">
            <div class="elementor-element elementor-element-199c6603 elementor-widget elementor-widget-text-editor"
              data-id="199c6603" data-element_type="widget" data-widget_type="text-editor.default">
              <div class="elementor-widget-container">
                <p>Contact us:</p>
                <ul>
                  <li>Contact@dedicatedpeople.us</li>
                  <li>Main office (337) 314-9711</li>
                  <li>Remote Office (999) 442 8084</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-69d9fa45"
          data-id="69d9fa45" data-element_type="column">
          <div class="elementor-widget-wrap elementor-element-populated">
            <div
              class="elementor-element elementor-element-7261b13a elementor-shape-square e-grid-align-left elementor-grid-0 elementor-widget elementor-widget-social-icons"
              data-id="7261b13a" data-element_type="widget" data-widget_type="social-icons.default">
              <div class="elementor-widget-container">
                <style>
                /*! elementor - v3.6.5 - 27-04-2022 */
                .elementor-widget-social-icons.elementor-grid-0 .elementor-widget-container,
                .elementor-widget-social-icons.elementor-grid-mobile-0 .elementor-widget-container,
                .elementor-widget-social-icons.elementor-grid-tablet-0 .elementor-widget-container {
                  line-height: 1;
                  font-size: 0
                }

                .elementor-widget-social-icons:not(.elementor-grid-0):not(.elementor-grid-tablet-0):not(.elementor-grid-mobile-0) .elementor-grid {
                  display: inline-grid
                }

                .elementor-widget-social-icons .elementor-grid {
                  grid-column-gap: var(--grid-column-gap, 5px);
                  grid-row-gap: var(--grid-row-gap, 5px);
                  grid-template-columns: var(--grid-template-columns);
                  -webkit-box-pack: var(--justify-content, center);
                  -ms-flex-pack: var(--justify-content, center);
                  justify-content: var(--justify-content, center);
                  justify-items: var(--justify-content, center)
                }

                .elementor-icon.elementor-social-icon {
                  font-size: var(--icon-size, 25px);
                  line-height: var(--icon-size, 25px);
                  width: calc(var(--icon-size, 25px) + (2 * var(--icon-padding, .5em)));
                  height: calc(var(--icon-size, 25px) + (2 * var(--icon-padding, .5em)))
                }

                .elementor-social-icon {
                  --e-social-icon-icon-color: #fff;
                  display: -webkit-inline-box;
                  display: -ms-inline-flexbox;
                  display: inline-flex;
                  background-color: #818a91;
                  -webkit-box-align: center;
                  -ms-flex-align: center;
                  align-items: center;
                  -webkit-box-pack: center;
                  -ms-flex-pack: center;
                  justify-content: center;
                  text-align: center;
                  cursor: pointer
                }

                .elementor-social-icon i {
                  color: var(--e-social-icon-icon-color)
                }

                .elementor-social-icon svg {
                  fill: var(--e-social-icon-icon-color)
                }

                .elementor-social-icon:last-child {
                  margin: 0
                }

                .elementor-social-icon:hover {
                  opacity: .9;
                  color: #fff
                }

                .elementor-social-icon-android {
                  background-color: #a4c639
                }

                .elementor-social-icon-apple {
                  background-color: #999
                }

                .elementor-social-icon-behance {
                  background-color: #1769ff
                }

                .elementor-social-icon-bitbucket {
                  background-color: #205081
                }

                .elementor-social-icon-codepen {
                  background-color: #000
                }

                .elementor-social-icon-delicious {
                  background-color: #39f
                }

                .elementor-social-icon-deviantart {
                  background-color: #05cc47
                }

                .elementor-social-icon-digg {
                  background-color: #005be2
                }

                .elementor-social-icon-dribbble {
                  background-color: #ea4c89
                }

                .elementor-social-icon-elementor {
                  background-color: #d30c5c
                }

                .elementor-social-icon-envelope {
                  background-color: #ea4335
                }

                .elementor-social-icon-facebook,
                .elementor-social-icon-facebook-f {
                  background-color: #3b5998
                }

                .elementor-social-icon-flickr {
                  background-color: #0063dc
                }

                .elementor-social-icon-foursquare {
                  background-color: #2d5be3
                }

                .elementor-social-icon-free-code-camp,
                .elementor-social-icon-freecodecamp {
                  background-color: #006400
                }

                .elementor-social-icon-github {
                  background-color: #333
                }

                .elementor-social-icon-gitlab {
                  background-color: #e24329
                }

                .elementor-social-icon-globe {
                  background-color: #818a91
                }

                .elementor-social-icon-google-plus,
                .elementor-social-icon-google-plus-g {
                  background-color: #dd4b39
                }

                .elementor-social-icon-houzz {
                  background-color: #7ac142
                }

                .elementor-social-icon-instagram {
                  background-color: #262626
                }

                .elementor-social-icon-jsfiddle {
                  background-color: #487aa2
                }

                .elementor-social-icon-link {
                  background-color: #818a91
                }

                .elementor-social-icon-linkedin,
                .elementor-social-icon-linkedin-in {
                  background-color: #0077b5
                }

                .elementor-social-icon-medium {
                  background-color: #00ab6b
                }

                .elementor-social-icon-meetup {
                  background-color: #ec1c40
                }

                .elementor-social-icon-mixcloud {
                  background-color: #273a4b
                }

                .elementor-social-icon-odnoklassniki {
                  background-color: #f4731c
                }

                .elementor-social-icon-pinterest {
                  background-color: #bd081c
                }

                .elementor-social-icon-product-hunt {
                  background-color: #da552f
                }

                .elementor-social-icon-reddit {
                  background-color: #ff4500
                }

                .elementor-social-icon-rss {
                  background-color: #f26522
                }

                .elementor-social-icon-shopping-cart {
                  background-color: #4caf50
                }

                .elementor-social-icon-skype {
                  background-color: #00aff0
                }

                .elementor-social-icon-slideshare {
                  background-color: #0077b5
                }

                .elementor-social-icon-snapchat {
                  background-color: #fffc00
                }

                .elementor-social-icon-soundcloud {
                  background-color: #f80
                }

                .elementor-social-icon-spotify {
                  background-color: #2ebd59
                }

                .elementor-social-icon-stack-overflow {
                  background-color: #fe7a15
                }

                .elementor-social-icon-steam {
                  background-color: #00adee
                }

                .elementor-social-icon-stumbleupon {
                  background-color: #eb4924
                }

                .elementor-social-icon-telegram {
                  background-color: #2ca5e0
                }

                .elementor-social-icon-thumb-tack {
                  background-color: #1aa1d8
                }

                .elementor-social-icon-tripadvisor {
                  background-color: #589442
                }

                .elementor-social-icon-tumblr {
                  background-color: #35465c
                }

                .elementor-social-icon-twitch {
                  background-color: #6441a5
                }

                .elementor-social-icon-twitter {
                  background-color: #1da1f2
                }

                .elementor-social-icon-viber {
                  background-color: #665cac
                }

                .elementor-social-icon-vimeo {
                  background-color: #1ab7ea
                }

                .elementor-social-icon-vk {
                  background-color: #45668e
                }

                .elementor-social-icon-weibo {
                  background-color: #dd2430
                }

                .elementor-social-icon-weixin {
                  background-color: #31a918
                }

                .elementor-social-icon-whatsapp {
                  background-color: #25d366
                }

                .elementor-social-icon-wordpress {
                  background-color: #21759b
                }

                .elementor-social-icon-xing {
                  background-color: #026466
                }

                .elementor-social-icon-yelp {
                  background-color: #af0606
                }

                .elementor-social-icon-youtube {
                  background-color: #cd201f
                }

                .elementor-social-icon-500px {
                  background-color: #0099e5
                }

                .elementor-shape-rounded .elementor-icon.elementor-social-icon {
                  border-radius: 10%
                }

                .elementor-shape-circle .elementor-icon.elementor-social-icon {
                  border-radius: 50%
                }
                </style>
                <div class="elementor-social-icons-wrapper elementor-grid">
                  <span class="elementor-grid-item">
                    <a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-repeater-item-6bc2d04"
                      href="https://www.facebook.com/DedicatedPeopleLA" target="_blank">
                      <span class="elementor-screen-only">Facebook</span>
                      <i class="lni lni-facebook-original"></i> </a>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <style id="skip-link-styles">
  .skip-link.screen-reader-text {
    border: 0;
    clip: rect(1px, 1px, 1px, 1px);
    clip-path: inset(50%);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute !important;
    width: 1px;
    word-wrap: normal !important;
  }

  .skip-link.screen-reader-text:focus {
    background-color: #eee;
    clip: auto !important;
    clip-path: none;
    color: #444;
    display: block;
    font-size: 1em;
    height: auto;
    left: 5px;
    line-height: normal;
    padding: 15px 23px 14px;
    text-decoration: none;
    top: 5px;
    width: auto;
    z-index: 100000;
  }
  </style>
  <script>
  (function() {
    var skipLinkTarget = document.querySelector('main'),
      sibling,
      skipLinkTargetID,
      skipLink;

    // Early exit if a skip-link target can't be located.
    if (!skipLinkTarget) {
      return;
    }

    // Get the site wrapper.
    // The skip-link will be injected in the beginning of it.
    sibling = document.querySelector('.wp-site-blocks');

    // Early exit if the root element was not found.
    if (!sibling) {
      return;
    }

    // Get the skip-link target's ID, and generate one if it doesn't exist.
    skipLinkTargetID = skipLinkTarget.id;
    if (!skipLinkTargetID) {
      skipLinkTargetID = 'wp--skip-link--target';
      skipLinkTarget.id = skipLinkTargetID;
    }

    // Create the skip link.
    skipLink = document.createElement('a');
    skipLink.classList.add('skip-link', 'screen-reader-text');
    skipLink.href = '#' + skipLinkTargetID;
    skipLink.innerHTML = 'Saltar al contenido';

    // Inject the skip link.
    sibling.parentElement.insertBefore(skipLink, sibling);
  }());
  </script>
  <link rel="stylesheet" id="e-animations-css" href="{{ asset('css/animations.min.css')}}" media="all">
  <script id="8cb199ab0-js-extra">
  var localize = {
    "ajaxurl": "https:\/\/elmercadomorado.com\/wp-admin\/admin-ajax.php",
    "nonce": "5d4e446e40",
    "i18n": {
      "added": "A\u00f1adido",
      "compare": "Comparar",
      "loading": "Cargando..."
    },
    "page_permalink": "https:\/\/elmercadomorado.com\/?e-landing-page=application"
  };
  </script>
  <script src="{{ asset('js/8cb199ab0.min.js')}}" id="8cb199ab0-js"></script>
  <script src="{{ asset('js/lottie.min.js')}}" id="lottie-js"></script>
  <script src="{{ asset('js/frontend.js')}}" id="animentor-frontend-js"></script>
  <script src="{{ asset('js/webpack.runtime.min.js')}}" id="elementor-webpack-runtime-js"></script>
  <script src="{{ asset('js/frontend-modules.min.js')}}" id="elementor-frontend-modules-js"></script>
  <script src="{{ asset('js/waypoints.min.js')}}" id="elementor-waypoints-js"></script>
  <script src="{{ asset('js/core.min.js')}}" id="jquery-ui-core-js"></script>
  <script id="elementor-frontend-js-before">
  var elementorFrontendConfig = {
    "environmentMode": {
      "edit": false,
      "wpPreview": false,
      "isScriptDebug": false
    },
    "i18n": {
      "shareOnFacebook": "Compartir en Facebook",
      "shareOnTwitter": "Compartir en Twitter",
      "pinIt": "Pinear",
      "download": "Descargar",
      "downloadImage": "Descargar imagen",
      "fullscreen": "Pantalla completa",
      "zoom": "Zoom",
      "share": "Compartir",
      "playVideo": "Reproducir v\u00eddeo",
      "previous": "Anterior",
      "next": "Siguiente",
      "close": "Cerrar"
    },
    "is_rtl": false,
    "breakpoints": {
      "xs": 0,
      "sm": 480,
      "md": 768,
      "lg": 1025,
      "xl": 1440,
      "xxl": 1600
    },
    "responsive": {
      "breakpoints": {
        "mobile": {
          "label": "M\u00f3vil",
          "value": 767,
          "default_value": 767,
          "direction": "max",
          "is_enabled": true
        },
        "mobile_extra": {
          "label": "M\u00f3vil grande",
          "value": 880,
          "default_value": 880,
          "direction": "max",
          "is_enabled": false
        },
        "tablet": {
          "label": "Tableta",
          "value": 1024,
          "default_value": 1024,
          "direction": "max",
          "is_enabled": true
        },
        "tablet_extra": {
          "label": "Tableta grande",
          "value": 1200,
          "default_value": 1200,
          "direction": "max",
          "is_enabled": false
        },
        "laptop": {
          "label": "Port\u00e1til",
          "value": 1366,
          "default_value": 1366,
          "direction": "max",
          "is_enabled": false
        },
        "widescreen": {
          "label": "Pantalla grande",
          "value": 2400,
          "default_value": 2400,
          "direction": "min",
          "is_enabled": false
        }
      }
    },
    "version": "3.6.5",
    "is_static": false,
    "experimentalFeatures": {
      "e_dom_optimization": true,
      "e_optimized_assets_loading": true,
      "e_optimized_css_loading": true,
      "a11y_improvements": true,
      "e_import_export": true,
      "additional_custom_breakpoints": true,
      "e_hidden_wordpress_widgets": true,
      "landing-pages": true,
      "elements-color-picker": true,
      "favorite-widgets": true,
      "admin-top-bar": true
    },
    "urls": {
      "assets": "http:\/\/elmercadomorado.com\/wp-content\/plugins\/elementor\/assets\/"
    },
    "settings": {
      "page": [],
      "editorPreferences": []
    },
    "kit": {
      "active_breakpoints": ["viewport_mobile", "viewport_tablet"],
      "global_image_lightbox": "yes",
      "lightbox_enable_counter": "yes",
      "lightbox_enable_fullscreen": "yes",
      "lightbox_enable_zoom": "yes",
      "lightbox_enable_share": "yes",
      "lightbox_title_src": "title",
      "lightbox_description_src": "description"
    },
    "post": {
      "id": 53,
      "title": "Application%20%E2%80%93%20El%20morado",
      "excerpt": "",
      "featuredImage": false
    }
  };
  </script>

  <script src="{{ asset('js/jquery.slim.min.js')}}"></script>
  <script src="{{ asset('js/hidShow.js')}}"></script>

  <script src="{{ asset('js/frontend.min.js?')}}" id="elementor-frontend-js"></script><span id="elementor-device-mode"
    class="elementor-screen-only"></span>


</body>

</html>