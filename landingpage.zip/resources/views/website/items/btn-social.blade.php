
<div class="btn-group">
    <a  class ="btn btn-link nav-link page-scroll" target="_blank" href="https://www.facebook.com/DedicatedPeopleLA" data-toggle="tooltip" title="Facebook DP!">
            <i style="font-size: 16px;" class="lni lni-facebook-oval"></i>
    </a>
    <a class ="btn btn-link nav-link page-scroll" target="_blank" href="https://www.computrabajo.com.mx/empresas/acerca-de-dedicated-people-9A15B15DF634FE84" data-toggle="tooltip" title="Compu Trabajo DP!">
        <i style="font-size: 16px;" class="lni lni-world"><strong>CT</strong></i>
    </a>
    <a class="btn btn-link nav-link page-scroll" target="_blank" href="https://www.linkedin.com/company/dedicated-people-llc/mycompany/?viewAsMember=true" data-toggle="tooltip" title="Linkedin DP!">
    	<i style="font-size: 16px;" class="lni lni-linkedin-original"></i>
    </a>
</div>

