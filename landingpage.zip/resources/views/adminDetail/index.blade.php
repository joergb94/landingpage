@extends('layouts.app')

@section('content')
    <detail></detail>
@endsection