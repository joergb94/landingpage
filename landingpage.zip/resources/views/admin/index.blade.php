@extends('layouts.app')

@section('content')
 <div class="row">
    <main-page></main-page>
    <about-us></about-us>
    <service></service>
    <career></career>
 </div>
@endsection